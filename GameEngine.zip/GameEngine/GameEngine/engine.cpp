#include "stdafx.h"
#include "engine.h"


Engine::Engine()
{
	Vector2f resolution;
	resolution.x = VideoMode::getDesktopMode().width; //sets default resolution for the width
	resolution.y = VideoMode::getDesktopMode().height; //sets default resolution for the height

	m_window.create(VideoMode(resolution.x, resolution.y), "Game Engine", Style::Default); //makes the window

	m_backgroundTexture.loadFromFile("background.jpg"); //loads the background texture

	m_backgroundSprite.setTexture(m_backgroundTexture); //sets the texture for the background sprite

	overFont.loadFromFile("pixeled.ttf"); //loads the font for game over
	gameOver.setFont(overFont);//sets the font for the game over text
	gameOver.setCharacterSize(50); //sets the character size in pixels
	gameOver.setColor(Color::Red);	//sets character color as red
	gameOver.setString("GAME OVER!"); //sets the string as Game Over
	gameOver.setOrigin((gameOver.getGlobalBounds().width) / 2, (gameOver.getGlobalBounds().height) / 2); //sets the origin to the middle of the text
	gameOver.setPosition((VideoMode::getDesktopMode().width) / 2, (VideoMode::getDesktopMode().height) / 2); //sets the position of the text to the middle of the screen
	playAlive = true;
}

void Engine::start()
{
	while (m_window.isOpen()) //Game Loop!
	{

		if (playAlive)
		{
			Time dt = clock.restart(); //makes a time for the clock

			float timeSec = dt.asSeconds(); //makes a variable which sends an update every second

			input(); //does the input function
			update(timeSec); //does the update function
			draw(); //does the draw function
		}

		else
		{
			m_window.clear(Color::Black); //if the player is not alive, it clears the screen to black
			m_window.draw(gameOver); //draws the game over text
			m_player.aliveText.setPosition((VideoMode::getDesktopMode().width) / 2, ((VideoMode::getDesktopMode().height) / 2) + 50); //sets position for the time alive text
			m_window.draw(m_player.aliveText); //draws the time that the player was alive
			m_window.display(); //displays the game over screen


			if (Keyboard::isKeyPressed(Keyboard::Escape))
			{
				m_window.close(); //if the user presses Esc Key, the game closes
			}
		}
	}
}