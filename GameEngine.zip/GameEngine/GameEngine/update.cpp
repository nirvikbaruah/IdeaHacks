#include "stdafx.h"
#include "engine.h"

using namespace sf;

void Engine::update(float timeSec)
{
	m_player.update(timeSec); //updates the player's position every second
	m_lava.update(timeSec); //updates the projectile's position every second

	if (m_lava.retSpr().getGlobalBounds().intersects(m_player.getSprite().getGlobalBounds()))
	{
		playAlive = false; //if the projectile touches the player, he is not alive
		m_lava.alive = false; //the same as above, but for the projectile module
	}
}