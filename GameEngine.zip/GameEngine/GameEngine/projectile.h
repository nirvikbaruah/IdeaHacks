#pragma once
#include <SFML/Graphics.hpp>
#include"inputUI.h"
using namespace sf; 
using namespace std;
class projectile
{
private:
	Vector2f m_lavaPos; // position of projectile 
	Texture m_lavaTex; // texture of the projectile
	Sprite m_lavaSpr; // sprite of the projectile 

	bool shooting; // to check if it is shooting 

public:
	projectile();
	bool alive;
	Sprite retSpr();
	void shoot();
	float m_gravity; // speed of projectile 
	void update(float timePass);
};
