#include "stdafx.h"
#include "player.h"
#include "engine.h"

using namespace sf;

player::player()
{
	m_speed = 500; //sets player speed

	m_texture.loadFromFile("player.png"); //loads texture for player
	m_sprite.setTexture(m_texture); //sets texture to player sprite

	m_position.x = 500; //sets player's starting position
	m_position.y = 800;	//sets player's starting position

	m_sprite.setOrigin((m_sprite.getGlobalBounds().width) / 2, 0); //sets the origin of the sprite to the middle
	timeAlive = 0; //sets time alive to 0
	aliveFont.loadFromFile("pixeled.ttf"); //loads font for the time alive
	aliveText.setFont(aliveFont); //sets font for the time alive
	aliveText.setOrigin(aliveText.getOrigin().x / 2, aliveText.getOrigin().y / 2); //sets the origin for the time alive to the middle
}

Sprite player::getSprite()
{
	return m_sprite; //returns the player's sprite
}

void player::moveLeft()
{
	m_leftPressed = true; //if the input module detects left movement, then it is true
}

void player::moveRight()
{
	m_rightPressed = true; //if the input module detects right movement, then it is true
}

void player::stopLeft()
{
	m_leftPressed = false; //if the input module detects the left movement stopping, then it is not true
}

void player::stopRight()
{
	m_rightPressed = false; //if the input module detects the right movement stopping, then it is not true
}

void player::update(float timeGone)
{
	if (m_rightPressed && m_position.x < VideoMode::getDesktopMode().width)
	{
		m_sprite.setScale(-1, 1); //flips the sprite if it is moving right
		m_position.x += m_speed * timeGone; //moves the sprite right

	}

	if (m_leftPressed && m_position.x > 0)
	{
		m_sprite.setScale(1, 1); //flips the sprite if it is going left
		m_position.x -= m_speed * timeGone; //moves the sprite left

	}
	timeAlive = timeAlive + timeGone; //updates the time the player is alive
	aliveText.setString(to_string(timeAlive)); //changes the time alive to string and sets it
	aliveText.setPosition(VideoMode::getDesktopMode().width - 100, VideoMode::getDesktopMode().height - 100); //sets the position for time alive
	m_sprite.setPosition(m_position); //sets position for the player
}
