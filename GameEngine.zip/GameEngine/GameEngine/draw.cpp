#include "stdafx.h"
#include "engine.h"

void Engine::draw()
{
	m_window.clear(Color::White); //makes the window white to begin with

	m_window.draw(m_backgroundSprite); //draws background
	m_window.draw(m_player.getSprite()); //draws the player
	m_window.draw(m_lava.retSpr()); //draws the projectile
	m_window.draw(m_player.aliveText); //draws the time the player is alive
	m_window.display(); //displays everything

}