//#pragma once
//#include <SFML/Graphics.hpp>
//using namespace sf;
//
//class ui
//{
//public:
//	float projSpeed;
//	float playSpeed;
//	Font font;
//	Text inputText;
//	Event text;
//	RenderWindow m_uiwindow;
//
//	ui();
//
//	void openUI();
//};