#include "stdafx.h"
#include <SFML/Graphics.hpp>
#include<SFML/Audio.hpp>
#include<iostream>
#include<conio.h>
#include "engine.h"

using namespace std;

void main()
{



	Engine engine;	// makes an object for the engine 
	engine.start(); // starts the engine 

	_getch();
}