#pragma once
#include <SFML/Graphics.hpp>
#include "player.h"
#include "projectile.h"
#include "inputUI.h"

using namespace sf;

class Engine
{
private:
	RenderWindow m_window; // renders a window 

	Sprite m_backgroundSprite; // window background 
	Texture m_backgroundTexture; // what the background looks like 

	void input(); // a function which determines what the input does 
	void update(float timeSec); // a function which gets an update for the position of the player, projectile etc... 
	void draw(); // draws everything on the screen 
	bool playAlive; // checks if the player is alive 
	Text gameOver; // text for game over	
	Font overFont; // font used for game over 
	Text inputSpeed;
	// later add on a counter for how many minutes the player has survived 

public:
	Engine(); // sets the default values for everything 
	player m_player; // makes an object for the player 
	projectile m_lava; // makes an object for the projectile 
	Clock clock; //sets a clock to show time
	void start(); // function to start the engine 
};


