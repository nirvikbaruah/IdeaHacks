#include "stdafx.h"
#include "projectile.h"
#include "engine.h"
#include "player.h"
using namespace std;
using namespace sf;

projectile::projectile()
{
	m_gravity = 1500;	//This changes the projectile's speed

	m_lavaTex.loadFromFile("projectile.png");	//loads the texture from the project directory

	m_lavaSpr.setTexture(m_lavaTex);	//sets the texture for the sprite


}

Sprite projectile::retSpr()
{
	return m_lavaSpr; //returns the sprite to other modules

}

void projectile::shoot()
{

	m_lavaPos.x = rand() % VideoMode::getDesktopMode().width; //sets a random position for the projectile
	m_lavaPos.y = 0;
	shooting = true;
}

void projectile::update(float timePass)
{
	if (m_lavaSpr.getPosition().y > VideoMode::getDesktopMode().height)
	{
		shooting = false; //stops shooting when the projectile goes off the screen
	}

	if (shooting)
	{
		m_lavaPos.y += m_gravity * timePass; //makes the projectile move
	}

	else
	{
		projectile::shoot(); //goes to the shoot function
	}

	m_lavaSpr.setPosition(m_lavaPos); //sets the position to update


}