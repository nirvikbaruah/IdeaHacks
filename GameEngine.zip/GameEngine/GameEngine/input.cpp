#include "stdafx.h"
#include "engine.h"

using namespace sf;

void Engine::input()
{
	if (Keyboard::isKeyPressed(Keyboard::Escape))
	{
		m_window.close(); //if escape is pressed, then close the window
	}

	if (Keyboard::isKeyPressed(Keyboard::A))
	{
		m_player.moveLeft(); //moves player left if A is pressed
	}
	else
	{
		m_player.stopLeft(); //if he is not moving left, then stop moving left
	}

	if (Keyboard::isKeyPressed(Keyboard::D))
	{
		m_player.moveRight(); //if D is pressed, move right
	}
	else
	{
		m_player.stopRight(); //if he is not moving right, then stop moving right
	}
}