#pragma once
#include <SFML/Graphics.hpp>
#include "inputUI.h"
using namespace sf; 
using namespace std;
class player
{
private:
	Vector2f m_position; // position of player 
	Sprite m_sprite; // sprite for player 
	Texture m_texture; // texture for the player sprite 

	bool m_leftPressed; // checks if the player has to move left 
	bool m_rightPressed; // checks if the player has to move right 


	float timeAlive;
public:
	player(); // default value 
	float m_speed; // speed of the player 
	Sprite getSprite(); // returns the player's sprite to other parts of the program 

	void moveLeft();	// function to move left 
	void moveRight();	// function to move right

	void stopLeft();	// function to stop moving left 
	void stopRight();	// function to stop moving right 
	Text aliveText;
	Font aliveFont;
	void update(float timeGone); // updates the player's position 
};
